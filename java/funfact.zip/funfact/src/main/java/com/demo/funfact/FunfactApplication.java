package com.demo.funfact;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FunfactApplication {

	public static void main(String[] args) {
		SpringApplication.run(FunfactApplication.class, args);
	}

}
